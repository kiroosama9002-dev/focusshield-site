(() => {
  const $ = (s) => document.querySelector(s);
  const href = location.href;
  const domain = (/[?&]d=([^&]+)/.exec(href) || [])[1] || '';
  const mu = /[?&]u=(.*)$/.exec(href);
  const original = mu ? mu[1] : '';
  $('#site').textContent = domain || 'This site';
  document.title = `Blocked · ${domain}`;
  let state = null, connected = false;

  chrome.runtime.sendMessage({ type: 'blocked', domain });

  function render() {
    const t = state && state.timer;
    const blocking = FS.isBlocking(state);
    FS.applySkin(state);
    document.documentElement.dataset.skin = (state && state.skin) || 'shield';
    const allowOnly = FS.allowOnly(state);
    $('#unlock').textContent = allowOnly ? 'Unlock this site (PIN / Windows Hello)' : 'Unlock with PIN / Windows Hello';
    $('#allow').hidden = !allowOnly;
    $('#site-text').textContent = allowOnly ? 'is not on your allowed list.' : 'is blocked by FocusShield.';
    const stillBlocked = FS.isHostBlocked(state, domain);
    if (state && !stillBlocked && original) { location.replace(original); return; }
    const clock = $('#clock');
    if (t && blocking) {
      clock.textContent = FS.fmt(FS.remaining(t));
      $('#clock-label').textContent = 'left in this focus session';
    } else {
      clock.textContent = '🔒';
      $('#clock-label').textContent = 'blocked by your blocklist (Always)';
    }
  }

  async function load() {
    const r = await chrome.runtime.sendMessage({ type: 'get' });
    state = r.state; connected = r.connected;
    render();
  }

  $('#back').onclick = () => {
    if (history.length > 1) history.back();
    else location.href = 'about:blank';
  };
  $('#unlock').onclick = async () => {
    const msg = $('#msg');
    const r = await chrome.runtime.sendMessage({ type: 'unlock', domain });
    if (r && r.ok) { msg.className = 'msg wait'; msg.textContent = 'Confirm in the FocusShield app — PIN or Windows Hello (−15 pts)…'; }
    else { msg.className = 'msg'; msg.textContent = 'FocusShield app is not running. Start it to unlock this site.'; }
  };

  $('#allow').onclick = async () => {
    const msg = $('#msg');
    const r = await chrome.runtime.sendMessage({ type: 'add-current', domain });
    if (r && r.ok) { msg.className = 'msg wait'; msg.textContent = 'Confirm in the FocusShield app to always allow this site…'; }
    else { msg.className = 'msg'; msg.textContent = 'FocusShield app is not running.'; }
  };

  chrome.storage.onChanged.addListener((c) => { if (c.fsState) load(); });
  chrome.runtime.onMessage.addListener((m) => { if (m.type === 'state') load(); });
  setInterval(render, 1000);
  load();
})();
