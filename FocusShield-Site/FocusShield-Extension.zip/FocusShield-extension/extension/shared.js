// Shared helpers (service worker + pages)
const FS = {
  WS_URL: 'ws://127.0.0.1:47321',
  DEFAULT: { blocking: false, expiresAt: 0, sites: [], tempAllow: [], timer: null, points: 0, unlockMinutes: 15 },

  isBlocking(state, now = Date.now()) {
    return !!state && state.blocking && (!state.expiresAt || now < state.expiresAt);
  },

  /** Allow-only mode: during focus every site is closed except the allowed ones. */
  allowOnly(state, now = Date.now()) {
    return !!state && state.siteMode === 'allowlist' && FS.isBlocking(state, now);
  },

  /** Domains that are open in allow-only mode (allowlist + temporary unlocks + localhost). */
  allowedDomains(state, now = Date.now()) {
    if (!state) return [];
    const temp = (state.tempAllow || []).filter((t) => t.until > now).map((t) => t.domain);
    return [...new Set([...(state.allow || []), ...temp, 'localhost', '127.0.0.1'])];
  },

  /** Domains from the blocklist that must be blocked right now. */
  activeDomains(state, now = Date.now()) {
    if (!state) return [];
    const blocking = FS.isBlocking(state, now);
    const listMode = state.siteMode !== 'allowlist';
    const allowed = new Set((state.tempAllow || []).filter((t) => t.until > now).map((t) => t.domain));
    return (state.sites || []).filter((s) => s.enabled && (s.always || (blocking && listMode)) && !allowed.has(s.domain)).map((s) => s.domain);
  },

  /** Is this hostname closed right now? */
  isHostBlocked(state, host, now = Date.now()) {
    if (!state) return false;
    if (FS.activeDomains(state, now).some((d) => FS.matches(host, d))) return true;
    return FS.allowOnly(state, now) && !FS.allowedDomains(state, now).some((d) => FS.matches(host, d));
  },

  matches(host, domain) {
    host = String(host || '').toLowerCase();
    return host === domain || host.endsWith('.' + domain);
  },

  SKINS: {
    shield: { acc: '#10b981', acc2: '#0d9488', bg: '#03050d', glow: '16,185,129' },
    ember: { acc: '#f97316', acc2: '#ea580c', bg: '#0a0f14', glow: '249,115,22' },
    sprint: { acc: '#4f6bff', acc2: '#7c5cff', bg: '#060a24', glow: '79,107,255' },
    aurora: { acc: '#5eead4', acc2: '#a78bfa', bg: '#0c0824', glow: '94,234,212' },
  },

  applySkin(state) {
    const k = FS.SKINS[(state && state.skin) || 'shield'] || FS.SKINS.shield;
    const r = document.documentElement.style;
    r.setProperty('--emerald', k.acc); r.setProperty('--emerald-2', k.acc); r.setProperty('--acc2', k.acc2);
    r.setProperty('--bg', k.bg); r.setProperty('--glow', k.glow);
  },

  fmt(sec) {
    sec = Math.max(0, Math.round(sec));
    return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
  },

  remaining(timer, now = Date.now()) {
    if (!timer) return 0;
    return timer.status === 'running' && timer.endsAt ? Math.max(0, Math.ceil((timer.endsAt - now) / 1000)) : timer.remainingSec;
  },
};
if (typeof self !== 'undefined') self.FS = FS;
