(() => {
  const $ = (s) => document.querySelector(s);
  const COLOR = { focus: null, short: '#f59e0b', long: '#38bdf8' };
  const NAME = { focus: 'Focus', short: 'Short break', long: 'Long break' };
  const CIRC = 276.46;
  const TABS = ['timer', 'tasks', 'sites'];
  let state = null, connected = false, skew = 0, tabNow = 'timer', curDomain = '';
  const open = new Set();
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const send = (m) => chrome.runtime.sendMessage(m);

  function setTab(t) {
    tabNow = t;
    document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.t === t));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('on', v.id === `v-${t}`));
    $('#tabpill').style.transform = `translateX(${TABS.indexOf(t) * 100}%)`;
    if (t === 'sites') loadCurrent();
  }

  function render() {
    FS.applySkin(state);
    document.documentElement.dataset.skin = (state && state.skin) || 'shield';
    const t = state && state.timer;
    const conn = $('#conn');
    conn.className = `conn ${connected ? '' : 'off'}`;
    conn.lastElementChild.textContent = connected ? 'Connected to app' : 'App not running';
    $('#pts').textContent = `${(state && state.points) || 0} PTS`;
    $('#who').textContent = state && state.user ? `${state.user.emoji} ${state.user.name}` : 'FocusShield';
    if (state && state.today) {
      const h = new Date().getHours();
      $('#greet').textContent = `${h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'}, ${state.user ? state.user.name : ''}`;
      $('#goaltxt').textContent = `${state.today.focusMin} / ${state.goal} min`;
      $('#goalfill').style.width = `${Math.min(100, Math.round((state.today.focusMin / state.goal) * 100))}%`;
      $('#t-focus').textContent = `${state.today.focusMin}m`; $('#t-pomo').textContent = state.today.pomodoros; $('#t-streak').textContent = state.today.streak;
    }
    renderTasks(); renderSites();
    if (!t) {
      $('#main').textContent = 'Open FocusShield app'; $('#main').disabled = true;
      $('#note').textContent = 'Start the FocusShield desktop app to link this extension.';
      return;
    }
    document.documentElement.style.setProperty('--phase', COLOR[t.phase] || getComputedStyle(document.documentElement).getPropertyValue('--emerald'));
    $('#phase').textContent = `${NAME[t.phase]}${t.status === 'paused' ? ' · paused' : ''}`;
    $('#sub').textContent = `Session ${t.sessionNum} of 4`;
    $('#dots').innerHTML = [1, 2, 3, 4].map((n) => `<i class="${n < t.sessionNum ? 'done' : n === t.sessionNum ? 'cur' : ''}"></i>`).join('');
    const main = $('#main');
    main.disabled = !connected;
    main.textContent = t.status === 'running' ? (t.phase === 'focus' && state.blocking ? 'Pause (needs PIN)' : 'Pause') : t.status === 'paused' ? 'Resume' : t.phase === 'focus' ? 'Start focus' : 'Start break';
    $('#skip').hidden = t.phase === 'focus';
    const allow = FS.allowOnly(state);
    const n = FS.activeDomains(state).length;
    $('#sites').textContent = allow ? 'All sites closed except your allowed list' : n ? `${n} site${n > 1 ? 's' : ''} blocked right now` : '';
    $('#note').textContent = connected ? '' : (FS.isBlocking(state) ? 'App is closed — blocking continues until this session ends.' : 'The desktop app is not running.');
    tick();
  }

  function renderTasks() {
    const list = (state && state.tasks) || [];
    const ae = document.activeElement;
    if (ae && ae.closest && ae.closest('#tlist')) return; // don't clobber typing
    const order = { High: 0, Medium: 1, Low: 2 };
    const tasks = [...list].sort((a, b) => a.completed - b.completed || order[a.priority] - order[b.priority] || a.id - b.id);
    $('#tlist').innerHTML = tasks.length ? tasks.map((t) => {
      const d = t.subs.filter((x) => x.done).length;
      return `<div class="t ${t.completed ? 'done' : ''}" data-id="${t.id}">
        <div class="h"><button class="ck" data-a="toggle">✓</button><span class="tx" data-a="open">${esc(t.text)}</span>${t.subs.length ? `<span class="cnt">${d}/${t.subs.length}</span>` : ''}<span class="p ${t.priority}" data-a="pri" title="Change priority">${t.priority[0]}</span><button class="xbtn" data-a="del" title="Delete">×</button></div>${t.subs.length ? `<div class="prog"><i style="width:${Math.round(d / t.subs.length * 100)}%"></i></div>` : ''}
        ${open.has(t.id) ? t.subs.map((x) => `<div class="sub ${x.done ? 'done' : ''}" data-s="${x.id}"><button class="ck" data-a="sub">✓</button><span class="tx">${esc(x.text)}</span></div>`).join('') + '<div class="subadd"><input placeholder="Add sub-task…" maxlength="120" /></div>' : ''}
      </div>`;
    }).join('') : '<div class="empty">No tasks yet — add one above</div>';
  }

  function renderSites() {
    if (!state) return;
    const allow = state.siteMode === 'allowlist';
    $('#modeline').textContent = allow ? 'Allow-only mode · allowed sites:' : 'Blocklist mode · blocked sites:';
    const list = allow ? state.allow || [] : (state.sites || []).filter((s) => s.enabled).map((s) => s.domain);
    $('#slist').innerHTML = list.length ? list.map((d) => `<span>${esc(d)}</span>`).join('') : '<small class="cnt">none yet</small>';
    const known = list.includes(curDomain);
    $('#addcur').textContent = allow ? 'Allow this site (PIN)' : 'Block this site';
    $('#addcur').disabled = !connected || !curDomain || known;
    $('#addcur').style.opacity = known ? '.5' : '';
    $('#sitenote').textContent = !curDomain ? 'Open a website tab to add it.' : known ? 'Already in the list.' : '';
  }

  async function loadCurrent() {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    curDomain = '';
    for (const t of tabs) { try { const u = new URL(t.url || ''); if (/^https?:$/.test(u.protocol)) curDomain = u.hostname; } catch { /* */ } }
    $('#curdom').textContent = curDomain || '—';
    renderSites();
  }

  function tick() {
    const t = state && state.timer;
    if (!t) return;
    const rem = FS.remaining(t, Date.now() + skew);
    $('#time').textContent = FS.fmt(rem);
    const arc = state.skin === 'ember' ? 0.75 : 1;
    $('#track').style.strokeDasharray = `${CIRC * arc} ${CIRC}`;
    $('#ring').style.strokeDasharray = `${CIRC * arc * (rem / Math.max(1, t.totalSec))} ${CIRC}`;
  }

  async function load() {
    const r = await send({ type: 'get' });
    state = r.state; connected = r.connected; skew = 0;
    render();
  }

  $('#tabs').onclick = (e) => { const b = e.target.closest('[data-t]'); if (b) setTab(b.dataset.t); };
  $('#main').onclick = async () => {
    const t = state && state.timer;
    if (!t) return;
    await send({ type: 'cmd', action: t.status === 'running' ? 'pause' : 'start' });
    if (t.status === 'running' && t.phase === 'focus' && state.blocking) $('#note').textContent = 'Confirm in the FocusShield app (PIN / Windows Hello).';
  };
  $('#skip').onclick = () => send({ type: 'cmd', action: 'skip' });
  $('#tform').onsubmit = (e) => { e.preventDefault(); const v = $('#tin').value.trim(); if (!v) return; $('#tin').value = ''; send({ type: 'task', op: 'add', text: v, priority: $('#tpri').value }); };
  $('#tlist').onclick = (e) => {
    const el = e.target.closest('[data-a]'); if (!el) return;
    const card = el.closest('.t'); const id = Number(card.dataset.id);
    if (el.dataset.a === 'toggle') send({ type: 'task', op: 'toggle', id });
    else if (el.dataset.a === 'sub') send({ type: 'task', op: 'sub-toggle', id, subId: Number(el.closest('.sub').dataset.s) });
    else if (el.dataset.a === 'pri') { const t = state.tasks.find((x) => x.id === id); send({ type: 'task', op: 'priority', id, priority: { High: 'Medium', Medium: 'Low', Low: 'High' }[t.priority] }); }
    else if (el.dataset.a === 'del') send({ type: 'task', op: 'delete', id });
    else if (el.dataset.a === 'open') { open.has(id) ? open.delete(id) : open.add(id); renderTasks(); }
  };
  $('#tlist').onkeydown = (e) => {
    if (e.key !== 'Enter' || !e.target.matches('.subadd input')) return;
    const v = e.target.value.trim(); if (!v) return;
    const id = Number(e.target.closest('.t').dataset.id);
    e.target.value = '';
    send({ type: 'task', op: 'sub-add', id, text: v });
  };
  $('#addcur').onclick = async () => {
    if (!curDomain) return;
    await send({ type: 'add-current', domain: curDomain });
    $('#sitenote').textContent = 'Confirm in the FocusShield app (PIN / Windows Hello).';
  };
  chrome.runtime.onMessage.addListener((m) => { if (m.type === 'state' || m.type === 'conn') load().then(loadCurrent); });
  setInterval(tick, 500);
  load();
})();
