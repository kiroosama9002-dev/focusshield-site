/* FocusShield extension — service worker.
 * Talks to the desktop app over ws://127.0.0.1:47321 and blocks sites with declarativeNetRequest.
 * The last known state is cached, so blocking keeps working until the current focus session
 * ends even if the app is closed. */
importScripts('shared.js');

let ws = null;
let state = null;
let reconnectTimer = null;
let backoff = 1500;

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const isConnected = () => !!ws && ws.readyState === 1;

async function loadState() {
  if (state) return state;
  const { fsState } = await chrome.storage.local.get('fsState');
  state = fsState || { ...FS.DEFAULT };
  return state;
}

async function saveState(s) {
  state = s;
  await chrome.storage.local.set({ fsState: s });
}

// ───────── blocking rules ─────────
const HOST_RE = '([^/:@]+)'; // captured host in allow-only mode
async function applyRules() {
  await loadState();
  const domains = FS.activeDomains(state);
  const allowOnly = FS.allowOnly(state);
  const base = chrome.runtime.getURL('blocked.html');
  const rules = [];
  let id = 1;
  if (allowOnly) {
    // Close everything (lowest priority) ...
    rules.push({
      id: id++, priority: 1,
      action: { type: 'redirect', redirect: { regexSubstitution: `${base}?d=\\2&u=\\1` } },
      condition: { regexFilter: '^(https?://(?:[^/@]*@)?' + HOST_RE + '(?::[0-9]+)?(?:/.*)?)$', resourceTypes: ['main_frame'] },
    });
    // ... then re-open the allowed domains.
    for (const d of FS.allowedDomains(state)) {
      rules.push({
        id: id++, priority: 2, action: { type: 'allow' },
        condition: { regexFilter: `^https?://([^/@]*@)?([^/:@]+\\.)?${escapeRe(d)}(:[0-9]+)?(/.*)?$`, resourceTypes: ['main_frame'] },
      });
    }
  }
  for (const d of domains) {
    rules.push({
      id: id++, priority: 3,
      action: { type: 'redirect', redirect: { regexSubstitution: `${base}?d=${d}&u=\\1` } },
      condition: { regexFilter: `^(https?://([^/@]*@)?([^/:@]+\\.)?${escapeRe(d)}(:[0-9]+)?(/.*)?)$`, resourceTypes: ['main_frame'] },
    });
  }
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existing.map((r) => r.id), addRules: rules });
  if (allowOnly || domains.length) redirectOpenTabs(base);
  scheduleExpiry();
  updateBadge();
}

async function redirectOpenTabs(base) {
  try {
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (!t.url || !/^https?:/.test(t.url)) continue;
      let host = '';
      try { host = new URL(t.url).hostname; } catch { continue; }
      if (FS.isHostBlocked(state, host)) chrome.tabs.update(t.id, { url: `${base}?d=${host}&u=${t.url}` }).catch(() => {});
    }
  } catch { /* ignore */ }
}

function scheduleExpiry() {
  const now = Date.now();
  const times = [];
  if (state && state.blocking && state.expiresAt > now) times.push(state.expiresAt);
  for (const t of (state && state.tempAllow) || []) if (t.until > now) times.push(t.until);
  if (times.length) chrome.alarms.create('expiry', { when: Math.min(...times) + 400 });
  else chrome.alarms.clear('expiry');
}

function updateBadge() {
  let text = '';
  let color = (FS.SKINS[(state && state.skin) || 'shield'] || FS.SKINS.shield).acc;
  if (!isConnected()) { text = '!'; color = '#f59e0b'; }
  else if (FS.isBlocking(state)) text = 'ON';
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
}

// ───────── websocket ─────────
function send(msg) {
  if (isConnected()) { ws.send(JSON.stringify(msg)); return true; }
  return false;
}

function connect() {
  if (ws && (ws.readyState === 0 || ws.readyState === 1)) return;
  clearTimeout(reconnectTimer);
  try {
    ws = new WebSocket(FS.WS_URL);
  } catch {
    return scheduleReconnect();
  }
  ws.onopen = () => {
    backoff = 1500;
    send({ type: 'hello', browser: 'chromium' });
    updateBadge();
    chrome.runtime.sendMessage({ type: 'conn', connected: true }).catch(() => {});
  };
  ws.onmessage = async (ev) => {
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    if (m.type === 'ping') return send({ type: 'pong' });
    if (m.type === 'get-active-site') {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      let domain = '';
      for (const t of tabs) {
        try { const u = new URL(t.url || ''); if (/^https?:$/.test(u.protocol)) domain = u.hostname; } catch { /* */ }
        if (!domain && t.url && t.url.startsWith(chrome.runtime.getURL('blocked.html'))) domain = (/[?&]d=([^&]+)/.exec(t.url) || [])[1] || '';
      }
      return send({ type: 'active-site', reqId: m.reqId, domain });
    }
    if (m.type === 'state') {
      await saveState({ ...m, receivedAt: Date.now() });
      await applyRules();
      chrome.runtime.sendMessage({ type: 'state' }).catch(() => {});
    }
  };
  ws.onclose = () => {
    ws = null;
    updateBadge();
    chrome.runtime.sendMessage({ type: 'conn', connected: false }).catch(() => {});
    scheduleReconnect();
  };
  ws.onerror = () => { /* onclose follows */ };
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, backoff);
  backoff = Math.min(backoff * 1.6, 10000);
}

// ───────── messages from popup / blocked page ─────────
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    await loadState();
    switch (msg.type) {
      case 'get':
        reply({ state, connected: isConnected(), now: Date.now() });
        break;
      case 'cmd':
        reply({ ok: send({ type: 'cmd', action: msg.action }) });
        break;
      case 'unlock':
        reply({ ok: send({ type: 'unlock-request', domain: String(msg.domain || '') }) });
        break;
      case 'task':
        reply({ ok: send({ type: 'task', op: msg.op, id: msg.id, subId: msg.subId, text: msg.text, priority: msg.priority }) });
        break;
      case 'add-current':
        reply({ ok: send({ type: 'add-current', domain: String(msg.domain || '') }) });
        break;
      case 'blocked':
        send({ type: 'blocked', domain: String(msg.domain || '') });
        reply({ ok: true });
        break;
      default:
        reply({});
    }
  })();
  return true; // async reply
});

// ───────── lifecycle ─────────
chrome.alarms.create('keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === 'keepalive') { if (!isConnected()) connect(); }
  if (a.name === 'expiry') await applyRules();
});
chrome.runtime.onInstalled.addListener(boot);
chrome.runtime.onStartup.addListener(boot);

async function boot() {
  await loadState();
  await applyRules();
  connect();
}
boot();

// ───────── website activity (domain + seconds only; no URLs or page content are sent) ─────────
const TRACK_MS = 5000;
setInterval(async () => {
  try {
    if (!isConnected()) return;
    const w = await chrome.windows.getLastFocused();
    if (!w || !w.focused) return;
    if ((await chrome.idle.queryState(90)) !== 'active') return;
    const [tab] = await chrome.tabs.query({ active: true, windowId: w.id });
    if (!tab || !tab.url || tab.incognito) return;
    const u = new URL(tab.url);
    if (!/^https?:$/.test(u.protocol)) return;
    send({ type: 'site-sec', domain: u.hostname, sec: TRACK_MS / 1000 });
  } catch { /* browser closing / worker restarting */ }
}, TRACK_MS);
